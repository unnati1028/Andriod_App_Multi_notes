package com.example.multi_notes;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class MyViewHolder extends RecyclerView.ViewHolder {

    public TextView title;
    public TextView date;
    public TextView content;

    public MyViewHolder(View view) {
        super(view);
        title = (TextView) view.findViewById(R.id.cardTitle);
        date = (TextView) view.findViewById(R.id.cardDate);
        content = (TextView) view.findViewById(R.id.cardContent);
    }
}